//
//  XIBLoadable_iOS.h
//  XIBLoadable-iOS
//
//  Created by Guilherme Galera Fortunato Freire on 05/10/23.
//

#import <Foundation/Foundation.h>

//! Project version number for XIBLoadable_iOS.
FOUNDATION_EXPORT double XIBLoadable_iOSVersionNumber;

//! Project version string for XIBLoadable_iOS.
FOUNDATION_EXPORT const unsigned char XIBLoadable_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XIBLoadable_iOS/PublicHeader.h>


